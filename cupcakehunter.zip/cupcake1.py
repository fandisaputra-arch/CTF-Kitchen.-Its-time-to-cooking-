import time
import sys

def loading():
    frames = ["[■□□□□]", "[■■□□□]", "[■■■□□]", "[■■■■□]", "[■■■■■]"]
    for _ in range(2):
        for f in frames:
            sys.stdout.write("\rMemproses data cupcake " + f)
            sys.stdout.flush()
            time.sleep(0.4)
    print()

start = time.time()

try:
    x = int(input("Ada berapa BLACK cupcake di foto itu? "))
except:
    sys.exit(0)

loading()

elapsed = time.time() - start

if x == 14 and elapsed > 8:
    print("CTF{gr3at_j00b_my_n1gg4}")
    sys.exit(0)

sys.exit(0)
